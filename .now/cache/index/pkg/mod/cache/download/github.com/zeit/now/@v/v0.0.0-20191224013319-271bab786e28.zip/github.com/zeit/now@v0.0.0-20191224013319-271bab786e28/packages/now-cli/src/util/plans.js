export default {
  oss: 'OSS',
  free: 'Free',
  premium: 'Premium',
  pro: 'Pro',
  advanced: 'Advanced',
  'on-demand': 'On Demand',
  unlimited: 'Unlimited'
};

import { gray } from 'chalk';

const effect = msg => `${gray(`+ ${msg}`)}`;

export default effect;

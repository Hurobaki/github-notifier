export const email = /.+@.+\..+$/;

// Base `.gitignore` to which we add entries
// supplied by the user
export default `.hg
.git
.gitmodules
.svn
.cache
.next
.now
.npmignore
.dockerignore
.gitignore
.*.swp
.DS_Store
.wafpicke-*
.lock-wscript
.env
.env.build
.venv
npm-debug.log
config.gypi
node_modules
__pycache__/
venv/
CVS`;

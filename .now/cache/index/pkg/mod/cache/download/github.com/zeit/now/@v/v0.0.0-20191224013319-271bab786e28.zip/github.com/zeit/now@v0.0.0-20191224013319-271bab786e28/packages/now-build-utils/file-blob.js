module.exports = require('./dist/index').FileBlob;

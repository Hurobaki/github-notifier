export function getBundledBuilders() {
  return [
    '@now/go',
    '@now/next',
    '@now/node',
    '@now/ruby',
    '@now/python',
    '@now/static-build',
    '@now/build-utils',
  ];
}

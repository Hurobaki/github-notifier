export const GA_TRACKING_ID = 'UA-117491914-3';
export const SENTRY_DSN = 'https://26a24e59ba954011919a524b341b6ab5@sentry.io/1323225';

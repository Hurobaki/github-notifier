import chalk from 'chalk';

const link = chalk.cyan.underline;

export default link;

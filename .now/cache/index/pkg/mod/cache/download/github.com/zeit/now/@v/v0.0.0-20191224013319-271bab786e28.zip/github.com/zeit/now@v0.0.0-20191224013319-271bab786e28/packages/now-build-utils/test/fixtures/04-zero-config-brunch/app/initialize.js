document.addEventListener('DOMContentLoaded', () => {
  // do your setup here
  console.log('Initialized app');
});

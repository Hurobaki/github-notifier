module.exports = {
  transform: {
    '^.+\\.tsx?$': 'ts-jest',
  },
};

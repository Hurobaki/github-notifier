import { cyan } from 'chalk';

const ready = msg => `${cyan('> Ready!')} ${msg}`;

export default ready;

declare module 'which-promise' {
  export default function (name: string): Promise<string>;
}

import React from 'react';

const IndexPage = () => (
  <div>
    <h1>Hi people</h1>
  </div>
);

export default IndexPage;

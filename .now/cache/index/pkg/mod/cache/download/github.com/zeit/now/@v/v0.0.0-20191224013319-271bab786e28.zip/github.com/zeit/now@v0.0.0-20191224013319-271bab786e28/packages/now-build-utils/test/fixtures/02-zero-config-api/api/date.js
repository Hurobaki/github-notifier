module.exports = (req, res) => {
  res.end('hello from api/date.js');
};

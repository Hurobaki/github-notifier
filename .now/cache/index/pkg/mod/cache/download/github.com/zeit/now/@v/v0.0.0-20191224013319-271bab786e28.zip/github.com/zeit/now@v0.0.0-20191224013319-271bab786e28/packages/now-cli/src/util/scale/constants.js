//

export const REGION_TO_DC = {
  all: 'all',
  bru: 'bru1',
  gru: 'gru1',
  sfo: 'sfo1',
  iad: 'iad1'
};

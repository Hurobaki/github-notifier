module.exports = require('../dist/index').glob;

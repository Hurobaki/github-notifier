module.exports = {
  plugins: [{ resolve: require.resolve('../../') }]
};

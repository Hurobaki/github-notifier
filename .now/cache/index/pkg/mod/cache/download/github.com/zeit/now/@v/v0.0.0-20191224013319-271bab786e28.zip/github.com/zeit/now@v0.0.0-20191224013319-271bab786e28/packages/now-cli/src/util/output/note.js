import { yellow } from 'chalk';

const note = msg => `${yellow('> NOTE:')} ${msg}`;

export default note;

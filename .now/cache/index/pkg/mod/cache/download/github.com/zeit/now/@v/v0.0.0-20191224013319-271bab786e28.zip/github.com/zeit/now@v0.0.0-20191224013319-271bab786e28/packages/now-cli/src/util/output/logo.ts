export default (process.platform === 'win32' ? 'Δ' : '𝚫');
